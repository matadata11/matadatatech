<?php defined('BASEPATH') OR exit('No direct script access allowed');

$config['version']   = '1.0a 2022';
$config['webmaster'] = 'Dwi Satria Pangestu';
$config['email']     = 'matadata.dev2021@gmail.com';
$config['auth']      = 'Digital Arfa Integration';